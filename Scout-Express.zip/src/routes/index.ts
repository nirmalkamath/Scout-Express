import { Router, Request, Response } from 'express';
import express from 'express';
import { pingDatabase } from '../db/mysql';

const router = Router();

router.get('/', (req: Request, res: Response) => {
  res.render('index');
});

// DB health check
router.get('/health/db', async (req: Request, res: Response) => {
  const ok = await pingDatabase();
  if (ok) {
    return res.json({ status: 'ok' });
  }
  return res.status(500).json({ status: 'error' });
});

// Login - render
router.get('/login', (req: Request, res: Response) => {
  res.render('login');
});

// Enable urlencoded to parse form submissions (scoped middleware)
router.use(express.urlencoded({ extended: true }));

// Login - submit (stubbed, validate and redirect)
router.post('/login', (req: Request, res: Response) => {
  const { email, password } = req.body as { email?: string; password?: string };

  if (!email || !password) {
    return res.status(400).render('login', { error: 'Please enter email and password.' });
  }

  // TODO: Replace with real auth. For now, pretend success and redirect home.
  return res.redirect('/');
});

// Signup - render
router.get('/signup', (req: Request, res: Response) => {
  res.render('signup');
});

// Signup - submit (stubbed, will be implemented with fields)
router.post('/signup', (req: Request, res: Response) => {
  // TODO: Implement registration logic with database
  // For now, redirect to login
  return res.redirect('/login');
});

export default router;


