document.addEventListener('DOMContentLoaded', function () {
  const countrySelect = document.getElementById('country');
  const stateSelect = document.getElementById('state');
  const districtSelect = document.getElementById('district');
  const citySelect = document.getElementById('city');

  // Simple geo dataset. Replace/expand with real datasets or API calls later.
  const geoData = {
    India: {
      Karnataka: {
        districts: {
          'Bengaluru Urban': ['Bengaluru', 'Yelahanka', 'Krishnarajapuram'],
          Mysuru: ['Mysuru', 'Nanjangud', 'Hunsur'],
        },
        cities: ['Bengaluru', 'Mysuru', 'Mangaluru'],
      },
      Maharashtra: {
        districts: {
          Pune: ['Pune', 'Pimpri-Chinchwad', 'Haveli'],
          Mumbai: ['Mumbai', 'Andheri', 'Bandra'],
        },
        cities: ['Mumbai', 'Pune', 'Nagpur'],
      },
    },
    USA: {
      California: {
        districts: {
          'Los Angeles County': ['Los Angeles', 'Pasadena', 'Burbank'],
          'San Diego County': ['San Diego', 'La Jolla', 'Chula Vista'],
        },
        cities: ['Los Angeles', 'San Diego', 'San Francisco'],
      },
      Texas: {
        districts: {
          'Harris County': ['Houston', 'Pasadena', 'Baytown'],
          'Travis County': ['Austin', 'Pflugerville', 'Lakeway'],
        },
        cities: ['Houston', 'Austin', 'Dallas'],
      },
    },
  };

  function resetSelect(select, placeholder, disabled = true) {
    select.innerHTML = '';
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = placeholder;
    select.appendChild(opt);
    select.disabled = disabled;
  }

  function populateSelect(select, values, placeholder) {
    resetSelect(select, placeholder, false);
    values.forEach((val) => {
      const opt = document.createElement('option');
      opt.value = val;
      opt.textContent = val;
      select.appendChild(opt);
    });
  }

  // Populate countries
  populateSelect(countrySelect, Object.keys(geoData), 'Select country');

  countrySelect.addEventListener('change', () => {
    const country = countrySelect.value;
    resetSelect(stateSelect, 'Select state');
    resetSelect(districtSelect, 'Select district');
    resetSelect(citySelect, 'Select city');

    if (!country || !geoData[country]) return;
    const states = Object.keys(geoData[country]);
    populateSelect(stateSelect, states, 'Select state');
  });

  stateSelect.addEventListener('change', () => {
    const country = countrySelect.value;
    const state = stateSelect.value;
    resetSelect(districtSelect, 'Select district');
    resetSelect(citySelect, 'Select city');

    if (!country || !state) return;
    const stateObj = geoData[country][state];
    if (!stateObj) return;

    // Districts
    const districts = Object.keys(stateObj.districts || {});
    if (districts.length) {
      populateSelect(districtSelect, districts, 'Select district');
    }

    // Cities (based on state)
    const cities = stateObj.cities || [];
    if (cities.length) {
      populateSelect(citySelect, cities, 'Select city');
    }
  });

  districtSelect.addEventListener('change', () => {
    // Optionally refine city list by district, if dataset supports it
    // For now, we keep the state-level cities.
  });
});


